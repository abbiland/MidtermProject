//
//  ListView.swift
//  LifeTracker.swift
//
//  Created by Brayden James on 3/15/22.
//

import SwiftUI
import Combine

struct ListView: View {
    @ObservedObject var taskStore = TaskStore()
    @State var newTask : String = ""
    @AppStorage("checked") private var unChecked = true
    @State var count : Int = 0
    
    var addTask : some View {
        HStack {
            TextField("New Task: ", text: self.$newTask)
            Button(action: self.addNewTask, label: {
                Text("Add Task")
                    .foregroundColor(Color.green)
                
            })
        }
    }
    
    func addNewTask() {
        taskStore.tasks.append(Task(id: String(taskStore.tasks.count + 1), toDoItem: newTask))
        self.newTask = ""
        unChecked = true // Always set a new item to be unchecked
    }
    
    var body: some View {
          VStack {
              Text("To-Do List")
                  .padding()
                  .font(.system(.largeTitle, design: .rounded))
                  .foregroundColor(.green)
                
            addTask.padding()
                List {
                    ForEach(self.taskStore.tasks) { task in
                        HStack {
                            if unChecked {
                                Button(action: self.checkBox, label : {
                                Image("Unfilled")
                         })
                         }
                            else {
                                Button(action: self.checkBox, label : {
                                Image("Filled")
                         })
                         }
                         Text(task.toDoItem)

                    }
                        
                }
          }
    }
    }

    
    func checkBox() {
        if unChecked == false {
            unChecked = true
        }
        else {
            unChecked = false
        }
    }
    
}


struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
