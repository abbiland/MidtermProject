//
//  LifeTracker_swiftApp.swift
//  LifeTracker.swift
//
//  Created by Brayden James on 3/15/22.
//

import SwiftUI

@main
struct LifeTracker_swiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
